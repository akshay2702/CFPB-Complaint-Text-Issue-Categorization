from flask import Flask, render_template, url_for, request
from predictor_api import make_classification
from ba_predictor_api import make_classification as ba_make_classification
from cc_predictor_api import make_classification as cc_make_classification
from cr_predictor_api import make_classification as cr_make_classification
from dc_predictor_api import make_classification as dc_make_classification
from ln_predictor_api import make_classification as ln_make_classification
from mrg_predictor_api import make_classification as mrg_make_classification
from mt_predictor_api import make_classification as mt_make_classification
from of_predictor_api import make_classification as of_make_classification
from pc_predictor_api import make_classification as pc_make_classification
from sa_predictor_api import make_classification as sa_make_classification

app = Flask(__name__)

# An example of routing:
# If they go to the page "/" (this means a GET request
# to go to the page httP://127.0.0.1:5000/)

# GET method is the type of request your web browser will send the website
# When it accesses the URL of the web page
@app.route("/")
def hello():
    return "It's alive!!!"


@app.route('/predict', methods=["GET", "POST"])
def predict():
    print(request.args)
    # This is a dictionary (JSON) object that contains 
    # the information submitted when someone clicks the ‘Submit’ button on our form.
    

    if (request.args):
        # request.args contains all the arguments passed by our form.
        # Comes built in with flask.
        # It is a dictionary of the form
        # "form name (as set in templatle)"
        # (key: "string in the textbox" (value)

        # by using request.args.get('chat_in'), it will take the 'name (key), "chat_in"' from the input button in the html file
        # and then it will take the associated value of "chat_in"
        x_input, category_prediction, list_of_pred_probs_dict = \
        make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None

        if category_prediction[:len(category_prediction)-1] == 'Debt collection':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            dc_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Credit reporting':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            cr_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Credit card':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            cc_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Bank account or service':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            ba_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Checking or savings account':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            sa_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Mortgage':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            mrg_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Loan':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            ln_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Prepaid card':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            pc_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Money transfers':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            mt_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        elif category_prediction[:len(category_prediction)-1] == 'Other financial service':
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            of_make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        else:
            x_input, issue_category_prediction, issue_list_of_pred_probs_dict = \
            make_classification(request.args.get('chat_in')) # if key doesn't exist, returns None
        
        return render_template('predictor.html', x_input=x_input, 
                                        cat_prediction = category_prediction, 
                                        prediction = list_of_pred_probs_dict,
                                        issue_cat_prediction = issue_category_prediction, 
                                        issue_prediction = issue_list_of_pred_probs_dict
                                        )

    else:
        # For the first load, request.args will be an 
        # empty ImmutableDict type
        # If this is the case we need to pass an empty string
        # into make_classification function so no errors are thrown.
        x_input, category_prediction, list_of_pred_probs_dict = make_classification('') 
        x_input, issue_category_prediction, issue_list_of_pred_probs_dict = make_classification('')
        issue_list_of_pred_probs_dict = list_of_pred_probs_dict
        for i in range(len(list_of_pred_probs_dict),30):
            issue_list_of_pred_probs_dict.append({'name': '', 'prob':0.0})
             
        category_prediction = 'I think you are concerned about...'
        issue_category_prediction = 'I think you are concerned about...'
        for dictionary in list_of_pred_probs_dict:
            for key, val in dictionary.items():
                dictionary[key] = '--'

        return render_template('predictor.html', x_input=x_input, 
                                         cat_prediction=category_prediction, 
                                         prediction = list_of_pred_probs_dict,
                                         issue_cat_prediction = issue_category_prediction, 
                                         issue_prediction = issue_list_of_pred_probs_dict
                                         )


# Start the server, continuously listen to requests

if __name__ == '__main__':
    # For local development, set to True:
    app.run(debug=True)

    # For public web serving:
    # app.run(host='0.0.0.0')
    # app.run()
